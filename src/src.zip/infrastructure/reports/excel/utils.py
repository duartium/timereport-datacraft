acentos = {
    "Analisis": "Análisis",
    "Capacitacion": "Capacitación",
    "Coordinacion": "Coordinación",
    "Generacion de backoffice Marglobal": "Generación de backoffice Marglobal",
    "Generacion de backoffice Marglobal ventanilla": "Generación de backoffice Marglobal ventanilla",
    "Gestion de permisos": "Gestión de permisos",
    "Gestion de recursos": "Gestión de recursos",
    "Implementacion": "Implementación",
    "Induccion": "Inducción",
    "Investigacion": "Investigación",
    "Planificacion": "Planificación",
    "Prueba de deposito especial en linea": "Prueba de depósito especial en línea",
    "Pruebas de notifiacion latina CNT": "Pruebas de notificación latina CNT",
    "Pruebas de notificaciones latina Claro": "Pruebas de notificación latina Claro",
    "Pruebas produccion": "Pruebas producción",
    "Reunion": "Reunión",
    "Reuniones": "Reunión",
    "Revision": "Revisión",
    "Retroespectiva": "Retrospectiva",
    "Revisiòn de correo y daily": "Revisión de correo y daily",
    "Revision de correo y daily": "Revisión de correo y daily",
    "Generacion de backoffice marglobal ventanilla": "Generación de backoffice marglobal ventanilla",
    "Pruebas de ntificacion latinia cnt": "Pruebas de notificación latinia cnt",
    "Verificacion": "Verificación"
}

def agregar_acentos(palabra):
    return acentos.get(palabra, palabra)